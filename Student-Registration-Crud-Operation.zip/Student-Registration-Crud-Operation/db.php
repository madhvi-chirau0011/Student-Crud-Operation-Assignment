<?php
$con = mysqli_connect('localhost','root','','user');
if($con){
	
}else{
	echo "Not Connected";
}

?>